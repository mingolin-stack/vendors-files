# 供應商資料表 PDF 掃描辨識工具

## 這是什麼

同仁把供應商填好、掃描成 PDF 的表格上傳到這個網頁，程式會：

1. 把 PDF 轉成圖片
2. 依照 `template.json` 裡校正好的座標，裁出每個欄位
3. 文字欄位送 Google Cloud Vision API 辨識(支援手寫)；勾選框用「黑色像素比例」判斷有沒有打勾(比 OCR 判斷「是不是 V」更穩，不受簽名字跡潦草影響)
4. 畫面顯示「裁切小圖 + 辨識建議值」，同仁核對、修正
5. 按確認後，寫入 Google Drive：
   - 該供應商自己的主檔(`供應商主檔/統編_公司名稱.xlsx`)：**每次提交新增一列**，天然形成歷史紀錄
   - `彙總總表.xlsx`：**每家供應商固定一列**，重複提交會覆蓋更新該列(用統一編號比對)，方便搜尋/篩選所有供應商

## 檔案說明

| 檔案 | 用途 |
|---|---|
| `streamlit_app.py` | 主程式 |
| `drive_utils.py` | 存取 Google Drive(尋找/建立資料夾、上傳/下載/更新檔案) |
| `vision_utils.py` | 呼叫 Vision API 做文字辨識；用像素比例判斷勾選框 |
| `master_utils.py` | 主檔/彙總表的讀寫邏輯(新增列、覆蓋更新列) |
| `template.json` | 欄位在掃描圖片上的座標校正檔(已用實際掃描範例驗證過，見附圖) |
| `requirements.txt` | 套件清單 |

## ⚠️ 目前的測試狀況(請注意)

以下部分**已經用您實際的掃描檔測試驗證過，可以放心**：
- ✅ 欄位座標校正(哪個欄位在圖片的哪個位置)— 已對照真實掃描檔逐一目視確認，像素等級精準
- ✅ 勾選框偵測邏輯(黑色像素比例判斷有沒有打勾)— 已用真實掃描檔測試，6 個有勾選、19 個沒勾選，全部正確
- ✅ 主檔/彙總表的存檔邏輯(新增列、覆蓋更新列)— 已用模擬資料完整測試，行為符合預期

以下部分**因為我開發的環境沒有對外網路，還沒辦法在這裡實際測試，需要您部署後親自試一次**：
- ⏳ Vision API 文字辨識的實際準確率(尤其是手寫內容)
- ⏳ Google Drive API 的實際讀寫(找資料夾、建立/更新檔案)

程式碼是照 Google 官方文件的標準寫法寫的，理論上應該可以直接動作，但**第一次部署後，麻煩您務必先用 1-2 份真實表格實際跑一次，確認辨識結果跟存檔位置都正確**，再正式讓同仁大量使用。如果有錯誤訊息，把訊息內容貼給我，我可以協助排除。

## 部署方式

跟之前的網頁工具一樣，用 Streamlit Community Cloud(免費)：

1. 建立 GitHub repository(建議設為 **Private**，比較安全)
2. 把這個資料夾裡的所有檔案上傳上去
3. 到 https://share.streamlit.io 用 GitHub 帳號登入，建立新 App，Main file path 填 `streamlit_app.py`
4. **重要：設定 Secrets** — 部署後，到 App 的設定(Settings) → Secrets，貼入：

```toml
drive_folder_id = "你的 Google Drive 資料夾 ID"

[gcp_service_account]
type = "service_account"
project_id = "你的專案ID"
private_key_id = "..."
private_key = "-----BEGIN PRIVATE KEY-----\n...(很長一串)...\n-----END PRIVATE KEY-----\n"
client_email = "...@....iam.gserviceaccount.com"
client_id = "..."
token_uri = "https://oauth2.googleapis.com/token"
```

上面這些值，除了 `drive_folder_id`，其他都可以直接從您下載的那個 `.json` 金鑰檔裡複製對應欄位過來(打開 .json 檔案用文字編輯器看，裡面每個欄位名稱都對得起來)。

**`drive_folder_id` 怎麼找**：打開您要存放供應商資料的 Google Drive 資料夾，網址列會長得像
`https://drive.google.com/drive/folders/1AbCdEfGhIjKlMnOpQrStUvWxYz`
最後那一串 `1AbCdEfGhIjKlMnOpQrStUvWxYz` 就是資料夾 ID。

5. 存檔後，Streamlit 會自動重新部署套用新的 Secrets，就可以開始使用了。

## 如果模板改版了

跟之前一樣，先用 `generate_schema.py`(針對電子檔 .docx)或人工方式校正出新的欄位座標，
更新 `template.json` 內容(格式：`{"name":欄位名, "type":"text"/"checkbox_single"/"checkbox_group", "box":[x0,y0,x1,y1]}`)，
上傳更新到 GitHub 上的同名檔案即可自動生效。

如果掃描解析度(DPI)跟目前的 200 不一樣，`template.json` 裡的座標需要等比例換算，或是統一約定所有掃描都固定用 200 DPI，比較不容易出錯。
